package SwervweKin.robot.src.main.java.edu.greenblitz.robot;



public class RobotMap {
	public static class Robot {
		public static class Joystick {
			public static final int MAIN = 0;
			public static final int SECOND = 1;
		}

	}
}